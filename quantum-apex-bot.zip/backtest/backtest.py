import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "bot"))

from market import fetch_klines
from strategy import get_signal

def main():
    candles = fetch_klines("BTCUSDT", "5m", 1000)

    buys = sells = holds = 0

    # This is a simple signal-count test, not a profitability guarantee.
    for i in range(101, len(candles)):
        signal, confidence = get_signal(candles[:i])
        if signal == "BUY":
            buys += 1
        elif signal == "SELL":
            sells += 1
        else:
            holds += 1

    print("Backtest sample:", len(candles), "candles")
    print("BUY signals:", buys)
    print("SELL signals:", sells)
    print("HOLD periods:", holds)
    print("This is research only; it does not prove future profitability.")

if __name__ == "__main__":
    main()
