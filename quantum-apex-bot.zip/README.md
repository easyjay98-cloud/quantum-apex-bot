# Quantum Apex Paper Trading Bot

A phone-friendly educational trading-bot project using Python and GitHub Actions.

## Important

This repository is **paper trading only**. It does not place real-money orders.

The strategy uses:
- EMA 10 / EMA 100
- RSI confirmation
- Percentage-based stop loss
- Risk-based position sizing
- 2:1 reward/risk target

## How it works

Phone → GitHub → GitHub Actions → Public market data → Strategy → Paper trade log

## Run locally

```bash
python bot/main.py
```

## Run the basic signal test

```bash
python backtest/backtest.py
```

## GitHub Actions

The workflow can be started manually from the Actions tab or run on its scheduled interval.

## Do not do this

- Do not add exchange API secrets to source files.
- Do not assume a backtest guarantees profit.
- Do not use leverage to try to rapidly double a tiny account.
- Do not treat confidence scores as a guarantee of winning.

For real trading, a broker/exchange with an appropriate API, minimum order size, fees, and age eligibility would need to be evaluated separately.
