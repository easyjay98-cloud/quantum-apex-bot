def calculate_position_size(balance, risk_percent, entry, stop):
    risk_amount = balance * (risk_percent / 100)
    distance = abs(entry - stop)

    if distance <= 0 or entry <= 0:
        return 0.0

    return risk_amount / distance

def stops(entry, side, stop_percent=0.5, reward_risk=2.0):
    if side == "BUY":
        stop = entry * (1 - stop_percent / 100)
        target = entry + (entry - stop) * reward_risk
    elif side == "SELL":
        stop = entry * (1 + stop_percent / 100)
        target = entry - (stop - entry) * reward_risk
    else:
        return None, None

    return stop, target
