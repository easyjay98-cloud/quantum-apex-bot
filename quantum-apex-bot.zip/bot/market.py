import json
import urllib.parse
import urllib.request

BINANCE_URL = "https://api.binance.com/api/v3/klines"

def fetch_klines(symbol="BTCUSDT", interval="5m", limit=200):
    params = urllib.parse.urlencode({
        "symbol": symbol,
        "interval": interval,
        "limit": limit,
    })
    req = urllib.request.Request(
        f"{BINANCE_URL}?{params}",
        headers={"User-Agent": "QuantumApexPaperBot/1.0"},
    )
    with urllib.request.urlopen(req, timeout=15) as response:
        raw = json.loads(response.read().decode("utf-8"))

    candles = []
    for row in raw:
        candles.append({
            "time": int(row[0]),
            "open": float(row[1]),
            "high": float(row[2]),
            "low": float(row[3]),
            "close": float(row[4]),
            "volume": float(row[5]),
        })
    return candles
