from dataclasses import dataclass

@dataclass
class PaperPosition:
    side: str
    entry: float
    quantity: float
    stop: float
    target: float

def open_paper_position(side, entry, quantity, stop, target):
    return PaperPosition(side, entry, quantity, stop, target)

def check_exit(position, candle):
    if position.side == "BUY":
        if candle["low"] <= position.stop:
            return "STOP", position.stop
        if candle["high"] >= position.target:
            return "TARGET", position.target

    if position.side == "SELL":
        if candle["high"] >= position.stop:
            return "STOP", position.stop
        if candle["low"] <= position.target:
            return "TARGET", position.target

    return None, None

def calculate_pnl(position, exit_price):
    if position.side == "BUY":
        return (exit_price - position.entry) * position.quantity
    return (position.entry - exit_price) * position.quantity
