import csv
import json
import os
from datetime import datetime, timezone

from market import fetch_klines
from strategy import get_signal
from risk import calculate_position_size, stops
from execution import open_paper_position

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load_config():
    with open(os.path.join(ROOT, "config.json"), "r", encoding="utf-8") as f:
        return json.load(f)

def log_signal(row):
    path = os.path.join(ROOT, "data", "trades.csv")
    exists = os.path.exists(path)

    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=row.keys())
        if not exists:
            writer.writeheader()
        writer.writerow(row)

def main():
    config = load_config()
    symbol = config["symbol"]
    interval = config["interval"]

    candles = fetch_klines(
        symbol=symbol,
        interval=interval,
        limit=config["market_data_limit"],
    )

    signal, confidence = get_signal(
        candles,
        config["fast_ema"],
        config["slow_ema"],
        config["rsi_period"],
    )

    last = candles[-1]
    entry = last["close"]

    print(f"Symbol: {symbol}")
    print(f"Time: {datetime.now(timezone.utc).isoformat()}")
    print(f"Price: {entry}")
    print(f"Signal: {signal}")
    print(f"Confidence: {confidence}%")

    if signal == "HOLD":
        return

    stop, target = stops(
        entry,
        signal,
        config["stop_percent"],
        config["reward_risk"],
    )

    quantity = calculate_position_size(
        config["starting_balance"],
        config["risk_percent"],
        entry,
        stop,
    )

    position = open_paper_position(signal, entry, quantity, stop, target)

    row = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "symbol": symbol,
        "side": position.side,
        "entry": round(position.entry, 8),
        "quantity": round(position.quantity, 8),
        "stop": round(position.stop, 8),
        "target": round(position.target, 8),
        "confidence": confidence,
        "mode": "PAPER",
    }
    log_signal(row)
    print("Paper trade recorded:", row)

if __name__ == "__main__":
    main()
