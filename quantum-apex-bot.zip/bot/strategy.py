def ema(values, period):
    if not values:
        return []
    alpha = 2 / (period + 1)
    result = [values[0]]
    for value in values[1:]:
        result.append(alpha * value + (1 - alpha) * result[-1])
    return result

def rsi(values, period=14):
    if len(values) < period + 1:
        return [50.0] * len(values)

    gains, losses = [], []
    for i in range(1, len(values)):
        change = values[i] - values[i - 1]
        gains.append(max(change, 0))
        losses.append(max(-change, 0))

    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    output = [50.0] * period

    def calc(g, l):
        if l == 0:
            return 100.0
        rs = g / l
        return 100 - (100 / (1 + rs))

    output.append(calc(avg_gain, avg_loss))

    for i in range(period, len(gains)):
        avg_gain = ((avg_gain * (period - 1)) + gains[i]) / period
        avg_loss = ((avg_loss * (period - 1)) + losses[i]) / period
        output.append(calc(avg_gain, avg_loss))

    return output

def get_signal(candles, fast_period=10, slow_period=100, rsi_period=14):
    closes = [c["close"] for c in candles]
    if len(closes) < slow_period + 2:
        return "HOLD", 0.0

    fast = ema(closes, fast_period)
    slow = ema(closes, slow_period)
    rsis = rsi(closes, rsi_period)

    prev_fast, curr_fast = fast[-2], fast[-1]
    prev_slow, curr_slow = slow[-2], slow[-1]
    current_rsi = rsis[-1]

    if prev_fast <= prev_slow and curr_fast > curr_slow and current_rsi >= 50:
        confidence = min(99.0, 70.0 + max(0, current_rsi - 50) * 0.6)
        return "BUY", round(confidence, 2)

    if prev_fast >= prev_slow and curr_fast < curr_slow and current_rsi <= 50:
        confidence = min(99.0, 70.0 + max(0, 50 - current_rsi) * 0.6)
        return "SELL", round(confidence, 2)

    return "HOLD", 0.0
